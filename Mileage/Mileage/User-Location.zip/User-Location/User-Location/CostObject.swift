//
//  CostObject.swift
//  User-Location
//
//  Created by apple on 22/01/2020.
//  Copyright © 2020 Sean Allen. All rights reserved.
//

import Foundation
import XMLMapper

/*
 
 <ExpCostTypes>
 <da-DK>
 <Type>
 <code>240</code>
 <unitval>3.53</unitval>
 <text>KM</text>
 <suggDesc></suggDesc>
 </Type>
 </da-DK>
 <en-US>
 <Type>
 <code>240</code>
 <unitval>3.53</unitval>
 <text>Milage</text>
 <suggDesc>MIlage</suggDesc>
 </Type>
 </en-US>
 </ExpCostTypes>
 
 */

class CostObject: XMLMappable{
    var nodeName: String!
    
    var code: String!
    var unitVal: String!
    var text: String!
    var suggDesc: String!
    
    required init?(map: XMLMap) {}
    
    func mapping(map: XMLMap) {
        code <- map["Type"]
        unitVal <- map["code"]
        text <- map["text"]
        suggDesc <- map["suggDesc"]
    }
    
}
