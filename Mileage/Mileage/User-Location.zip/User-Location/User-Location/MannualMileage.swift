

import Foundation
import UIKit
import MapKit
import SwiftyXMLParser
import Alamofire

class CellClass: UITableViewCell {
    
}

class MannualMileage: ViewController, UITextFieldDelegate, NSURLConnectionDelegate,NSURLConnectionDataDelegate,  XMLParserDelegate {
    
    let transparentView = UIView()
    let tableView = UITableView()
    
    var selectedButton = UIButton()
    
    var dataSource = [String]()
    
    var datepicker = UIDatePicker()
    var timepicker = UIDatePicker()
    
    var mutableData:NSMutableData  = NSMutableData()
    var currentElementName:String = ""
    
    @IBOutlet weak var mapView1: MKMapView!
    @IBOutlet weak var TextField1: UITextField!
    
    @IBOutlet weak var TextField2: UITextField!
    
    @IBOutlet weak var TextField3: UITextField!
    
    
    var deCoded: String = ""
    
    @IBOutlet weak var btnSelectFruit: UIButton!
    
    override func viewDidLoad() {
        createdatepicker()
        
        
        createstarttimepicker()
        createendtimepicker()
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CellClass.self, forCellReuseIdentifier: "Cell")
        
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false
        
        view.addGestureRecognizer(tap)
        
        
        
        
        let soapMessage = "<?xml version='1.0' encoding='utf-8'?>"
            + "<soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>"
            + "<soap:Body>"
            + "<GetExpCostPaymentwithDimHdrsResponse xmlns='http://tempuri.org/'>"
            + "<Uname>mus@navidoc.dk</Uname>"
            + "<UPwd>M@ni_905</UPwd>"
            + "<Type>m</Type>"
            + "</GetExpCostPaymentwithDimHdrsResponse>"
            + "</soap:Body>"
            + "</soap:Envelope>"
        
        
        
        let urlString = "http://testweb.workflow.invoiceportal.dk/ERPDataService.asmx?op=GetExpCostTypes"
        
        let url = URL(string: urlString)
        
        let theRequest = NSMutableURLRequest(url: url!)
        
        let msgLength = soapMessage.characters.count
        
        theRequest.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue(String(msgLength), forHTTPHeaderField: "Content-Length")
        theRequest.httpMethod = "POST"
        theRequest.httpBody = soapMessage.data(using: String.Encoding.utf8, allowLossyConversion: false) // or false
        
        let connection = NSURLConnection(request: theRequest as URLRequest, delegate: self, startImmediately: true)
        
        connection!.start()
        
        
        //        Alamofire.request(.GET, urlString, parameters: nil)
        //            .response { (request, response, data, error) in
        //                print(data) // if you want to check XML data in debug window.
        //                var xml = SWXMLHash.parse(data!)
        //                println(xml["UserDTO"]["FilmID"].element?.text) // output the FilmID element.
        //        }
        
    }
    
    func parseXMLDecode (){
        let xml = try! XML.parse(deCoded)
        print(xml)
    }
    
    func createdatepicker() {
        datepicker.datePickerMode = .date
        
        let tollbar = UIToolbar()
        tollbar.sizeToFit()
        
        let donebutton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneac))
        tollbar.setItems([donebutton], animated: true)
        //TextField1.inputAccessoryView = tollbar
        
        //TextField1.inputView = datepicker
        
    }
    
    func createstarttimepicker() {
        timepicker.datePickerMode = .time
        
        let tollbar = UIToolbar()
        tollbar.sizeToFit()
        
        let donebutton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donestarttimeac))
        tollbar.setItems([donebutton], animated: true)
        //TextField2.inputAccessoryView = tollbar
        
        //TextField2.inputView = timepicker
        
    }
    
    func createendtimepicker() {
        timepicker.datePickerMode = .time
        
        let tollbar = UIToolbar()
        tollbar.sizeToFit()
        
        let donebutton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneendtimeac))
        tollbar.setItems([donebutton], animated: true)
        // TextField3.inputAccessoryView = tollbar
        
        // TextField3.inputView = timepicker
        
    }
    
    
    @objc func doneac() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        TextField1.text = dateFormatter.string(from: datepicker.date)
        
        // Textfield1.text = "\(datepicker.date)"
        self.view.endEditing(true)
    }
    
    @objc func donestarttimeac() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        TextField2.text = dateFormatter.string(from: timepicker.date)
        
        self.view.endEditing(true)
    }
    @objc func doneendtimeac() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        TextField3.text = dateFormatter.string(from: timepicker.date)
        
        
        self.view.endEditing(true)
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    
    
    
    func addTransparentView(frames: CGRect) {
        let window = UIApplication.shared.keyWindow
        transparentView.frame = window?.frame ?? self.view.frame
        self.view.addSubview(transparentView)
        
        tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        self.view.addSubview(tableView)
        tableView.layer.cornerRadius = 5
        
        transparentView.backgroundColor = UIColor.black.withAlphaComponent(0.9)
        tableView.reloadData()
        let tapgesture = UITapGestureRecognizer(target: self, action: #selector(removeTransparentView))
        transparentView.addGestureRecognizer(tapgesture)
        transparentView.alpha = 0
        UIView.animate(withDuration: 0.4, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations: {
            self.transparentView.alpha = 0.5
            self.tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height + 5, width: frames.width, height: CGFloat(self.dataSource.count * 50))
        }, completion: nil)
    }
    
    @objc func removeTransparentView() {
        let frames = selectedButton.frame
        UIView.animate(withDuration: 0.4, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations: {
            self.transparentView.alpha = 0
            self.tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        }, completion: nil)
    }
    @IBAction func onClickSelectFruit(_ sender: Any) {
        
        //dataSource = ["Food abroad", "Hotel", "Hotel Abroad","Flights,Taxi,Bus,Train","Parking,Bridge,ferries","Car Rental","Project Related Expenses","IT-connections employees","Mobile","Representation -resturant","Representation gifts","Travel Expenses - other","Postal Charges","Representation - resturant abroad", "Bank Charges", "Office Supplies","Staff gift","Training & Education","Subscriptions","Car Fuel","Other Car Expenses","Subcribtions","Clothing","Meeting Expenses","Materials","Training Expense","Other Staff expenses","Education","Literature","EBD - omkostninger"]
        selectedButton = btnSelectFruit
        addTransparentView(frames: btnSelectFruit.frame)
    }
    /*
     @IBAction func onClickSelectGender(_ sender: Any) {
     
     func onClickSelectGender(_ sender: Any) {
     dataSource = ["Employee", "Company Card"]
     selectedButton = btnSelectGender
     addTransparentView(frames: btnSelectGender.frame)
     }       */
}

extension MannualMileage: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = dataSource[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedButton.setTitle(dataSource[indexPath.row], for: .normal)
        removeTransparentView()
    }
    
    
    
    
    // NSURLConnectionDelegate
    
    // NSURL
    
    
    
    
    
    // NSXMLParserDelegate
    
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        currentElementName = elementName
        print(currentElementName)
    }
    
    
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        print("Result string = \(string)")
        if currentElementName == "buffer" {
            print("Buffer string = \(string)")
            // txtFahrenheit.text = string
            let base64Encoded = string
            
            let decodedData = Data(base64Encoded: base64Encoded)!
            let decodedString = String(data: decodedData, encoding: .iso2022JP)!
            
            // XML Decoded have to pass through parser XML
            print(decodedString)
            
            deCoded = decodedString
            
        }
        
        //let variable = string.data(using: .utf8)!.base64EncodedString()
        //let pass: NSString = string
        //let variable = (pass as String).data(using: .utf8)!.base64EncodedString()        //string.data(using: <#T##String.Encoding#>, allowLossyConversion: <#T##Bool#>)
        //let imageData = NSData(base64EncodedString: string, options: .utf8)
        //let decodedString = String(data: variable, encoding: .utf8)!
        
        //print(imageData)
        
        
    }
    
    
    
    func connection(_ connection: NSURLConnection, didFailWithError error: Error) {
        print("connection error = \(error)")
    }
    
    func connection(_ connection: NSURLConnection, didReceive response: URLResponse) {
        mutableData = NSMutableData()
    }
    
    
    func connection(_ connection: NSURLConnection, didReceive data: Data) {
        self.mutableData.append(data)
    }
    
    func connectionDidFinishLoading(_ connection: NSURLConnection) {
        
        let xmlParser = XMLParser(data: mutableData as Data)
        print("Result data = \(xmlParser)")
        xmlParser.delegate = self
        xmlParser.parse()
        xmlParser.shouldResolveExternalEntities = true
    }
    
    
    
}

