
import Foundation
import UIKit
//import Alamofire
//import ObjectMapper



class ViewController: UIViewController {
var is_SoapMessage: String = "<soapenv:Envelope xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">.com/\"><soapenv:Header/><soapenv:Body><cgs:GetSystemStatus/>userName</soapenv:Body>userPass</soapenv:Envelope>"

override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
}

override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}

    @IBAction func loginButtonTapped(sender: AnyObject)
    //@IBAction func btnClicked(sender: AnyObject)
{
    let is_URL: String = "http://web.workflow.invoiceportal.dk/ERPDataService.asmx"

    let lobj_Request = NSMutableURLRequest(url: NSURL(string: is_URL)! as URL)
    let session = URLSession.shared
    var _: NSError?

    lobj_Request.httpMethod = "POST"
   // lobj_Request.httpBody = is_SoapMessage.data(usingEncoding:String.Encoding)

    lobj_Request.addValue("http://tempuri.org/\"", forHTTPHeaderField: "Host")
    lobj_Request.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
    //lobj_Request.addValue(String(count(is_SoapMessage)), forHTTPHeaderField: "Content-Length")
    //lobj_Request.addValue("223", forHTTPHeaderField: "Content-Length")
    lobj_Request.addValue("http://www.w3.org/2001/XMLSchema-instance\"", forHTTPHeaderField: "SOAPAction")

    let task = session.dataTask(with: lobj_Request as URLRequest, completionHandler: {data, response, error -> Void in
       // println("Response: \(response)")

        if error != nil
        {
           // println("Error: " + error.description)
        }

    })
    task.resume()
}

}
